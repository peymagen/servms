import * as userService from "./user.service";
import { createResponse } from "../../common/helper/response.hepler";
import { logAudit } from "../../common/services/auditLog.service";
import {
  isDivisionScoped,
  assertRecordAccessible,
  assertCanManageAdminTier,
  assertDivisionForScopedRole,
  assertOwnDivisionRecord,
  pinToOwnDivision,
} from "../../common/constants/roles";
import asyncHandler from "express-async-handler";
import { type Request, type Response } from "express";
import passport from "passport";
import { createUserTokens } from "../../common/services/passport-jwt.service";
import bcrypt from "bcrypt";

// ─── Helper ────────────────────────────────────────────────────────────────────
const hashPassword = async (password: string): Promise<string> => {
  return bcrypt.hash(password, 12);
};

// ─── CREATE USER ───────────────────────────────────────────────────────────────
export const createUser = asyncHandler(async (req: Request, res: Response) => {
  if (req.file) {
    req.body.signature_path = `/uploads/${req.file.filename}`;
  }
  req.body.card_signing_authority = req.body.card_signing_authority === "true" || req.body.card_signing_authority === true;

  const targetRoleName = req.body.role_id ? await userService.getRoleName(Number(req.body.role_id)) : null;
  assertCanManageAdminTier(req.user as any, targetRoleName);
  pinToOwnDivision(req.user as any, req.body);
  assertDivisionForScopedRole(targetRoleName, req.body.division_id);

  req.body.password = await hashPassword(req.body.password); // ✅ await fixed
  const result = await userService.createUser(req.body);
  await logAudit({
    req,
    module: "user_management",
    recordId: result.insertId,
    action: "CREATE",
    newData: { ...req.body, password: undefined },
  });
  res.send(createResponse(result, "User created successfully"));
});

// ─── LOGIN ─────────────────────────────────────────────────────────────────────
export const loginUser = asyncHandler(async (req: Request, res: Response) => {
  console.log("Loginn attempt for username:", req.body?.username); // Debug log — never log the password
  passport.authenticate(
    "login",
    async (err: Error | null, user: any | undefined, info: any) => {
      if (err || !user) {
        return res.status(401).json({
          message: info?.message || "Authentication failed",
        });
      }
      // Update last_login timestamp on successful login
      await userService.updateLastLogin(user.id);
      const { accessToken } = createUserTokens(user);
      res.send(createResponse({ accessToken, user }, "Login successful"));
    }
  )(req, res);
});

// ─── FULL UPDATE (PUT) ─────────────────────────────────────────────────────────
export const updateUser = asyncHandler(async (req: Request, res: Response) => {
  if (req.file) {
    req.body.signature_path = `/uploads/${req.file.filename}`;
  }
  const before = await userService.getUserById(req.params.id as string);
  assertOwnDivisionRecord(req.user as any, before as any);
  if (req.body.division_id !== undefined) pinToOwnDivision(req.user as any, req.body);
  const targetRoleName = req.body.role_id ? await userService.getRoleName(Number(req.body.role_id)) : null;
  assertCanManageAdminTier(req.user as any, before?.role_name, targetRoleName);
  assertDivisionForScopedRole(
    targetRoleName ?? before?.role_name,
    req.body.division_id !== undefined ? req.body.division_id : before?.division_id
  );

  if (req.body.password) {
    req.body.password = await hashPassword(req.body.password); // ✅ await fixed
  }
  const result = await userService.updateUser(req.params.id as string, req.body);
  await logAudit({
    req,
    module: "user_management",
    recordId: req.params.id,
    action: "UPDATE",
    oldData: before,
    newData: { ...req.body, password: undefined },
  });
  res.send(createResponse(result, "User updated successfully"));
});

// ─── PARTIAL UPDATE (PATCH) ────────────────────────────────────────────────────
export const editUser = asyncHandler(async (req: Request, res: Response) => {
  if (req.file) {
    req.body.signature_path = `/uploads/${req.file.filename}`;
  }
  if (req.body.card_signing_authority !== undefined) {
    req.body.card_signing_authority = req.body.card_signing_authority === "true" || req.body.card_signing_authority === true;
  }
  const before = await userService.getUserById(req.params.id as string);
  assertOwnDivisionRecord(req.user as any, before as any);
  if (req.body.division_id !== undefined) pinToOwnDivision(req.user as any, req.body);
  const targetRoleName = req.body.role_id ? await userService.getRoleName(Number(req.body.role_id)) : null;
  assertCanManageAdminTier(req.user as any, before?.role_name, targetRoleName);
  assertDivisionForScopedRole(
    targetRoleName ?? before?.role_name,
    req.body.division_id !== undefined ? req.body.division_id : before?.division_id
  );

  if (req.body.password) {
    // Hash and store under the correct column name before passing to service
    req.body.password_hash = await hashPassword(req.body.password); // ✅ await fixed
    delete req.body.password;
  }
  const result = await userService.editUser(req.params.id as string, req.body);
  await logAudit({
    req,
    module: "user_management",
    recordId: req.params.id,
    action: "UPDATE",
    oldData: before,
    newData: { ...req.body, password_hash: undefined },
  });
  res.send(createResponse(result, "User patched successfully"));
});

// ─── DELETE ────────────────────────────────────────────────────────────────────
export const deleteUser = asyncHandler(async (req: Request, res: Response) => {
  const before = await userService.getUserById(req.params.id as string);
  assertOwnDivisionRecord(req.user as any, before as any);
  assertCanManageAdminTier(req.user as any, before?.role_name);
  const result = await userService.deleteUser(req.params.id as string);
  await logAudit({ req, module: "user_management", recordId: req.params.id, action: "DELETE", oldData: before });
  res.send(createResponse(result, "User deleted successfully"));
});

// ─── GET CURRENT USER ──────────────────────────────────────────────────────────
export const getMe = asyncHandler(async (req: Request, res: Response) => {
  const result = await userService.getUserById(String((req.user as any)?.id));
  if (!result) {
    res.status(404).send(createResponse(null, "User not found"));
    return;
  }
  res.send(createResponse(result));
});

// ─── GET BY ID ─────────────────────────────────────────────────────────────────
export const getUserById = asyncHandler(async (req: Request, res: Response) => {
  const result = await userService.getUserById(req.params.id as string);
  if (!result) {
    res.status(404).send(createResponse(null, "User not found"));
    return;
  }
  assertRecordAccessible(req.user as any, result as any);
  res.send(createResponse(result));
});

// ─── GET ALL ───────────────────────────────────────────────────────────────────
export const getAllUser = asyncHandler(async (req: Request, res: Response) => {
  const user = req.user as any;
  const divisionId = isDivisionScoped(user?.role_name) ? user.division_id : undefined;
  const result = await userService.getAllUsers(divisionId);
  res.send(createResponse(result));
});

// ─── TOGGLE STATUS ─────────────────────────────────────────────────────────────
export const toggleStatus = asyncHandler(async (req: Request, res: Response) => {
  const before = await userService.getUserById(req.params.id as string);
  assertOwnDivisionRecord(req.user as any, before as any);
  assertCanManageAdminTier(req.user as any, before?.role_name);
  const result = await userService.toggleStatus(req.params.id as string);
  await logAudit({
    req,
    module: "user_management",
    recordId: req.params.id,
    action: "STATUS_CHANGE",
    oldData: before,
    newData: result,
  });
  res.send(createResponse(result, "User status toggled successfully"));
});

// ─── APPROVE / REJECT (Divisional/HQ Admin only, via can_approve_reject) ───────
export const approveUser = asyncHandler(async (req: Request, res: Response) => {
  const before = await userService.getUserById(req.params.id as string);
  if (!before) {
    res.status(404).send(createResponse(null, "User not found"));
    return;
  }
  assertOwnDivisionRecord(req.user as any, before as any);
  const result = await userService.approveUser(req.params.id as string);
  await logAudit({
    req,
    module: "user_management",
    recordId: req.params.id,
    action: "APPROVE",
    oldData: { users_status: result.previousStatus },
    newData: { users_status: result.newStatus },
  });
  res.send(createResponse(result, "User approved"));
});

export const rejectUser = asyncHandler(async (req: Request, res: Response) => {
  const before = await userService.getUserById(req.params.id as string);
  if (!before) {
    res.status(404).send(createResponse(null, "User not found"));
    return;
  }
  assertOwnDivisionRecord(req.user as any, before as any);
  const result = await userService.rejectUser(req.params.id as string, req.body?.reason);
  await logAudit({
    req,
    module: "user_management",
    recordId: req.params.id,
    action: "REJECT",
    oldData: { users_status: result.previousStatus },
    newData: { users_status: result.newStatus },
    details: req.body?.reason,
  });
  res.send(createResponse(result, "User rejected"));
});

// ─── CHANGE PASSWORD ───────────────────────────────────────────────────────────
export const changePassword = asyncHandler(async (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  const user = await userService.getUserById(req.params.id as string);
  if (!user) {
    res.status(404).send(createResponse(null, "User not found"));
    return;
  }
  const dbUser = await userService.getUserByUsername((user as any).username);
  if (!dbUser) {
    res.status(404).send(createResponse(null, "User details not found"));
    return;
  }
  const isMatch = await bcrypt.compare(currentPassword, (dbUser as any).password_hash);
  if (!isMatch) {
    res.status(400).send(createResponse(null, "Current password is incorrect"));
    return;
  }
  const newHash = await hashPassword(newPassword);
  const result = await userService.changePassword(req.params.id as string, newHash);
  await logAudit({ req, module: "user_management", recordId: req.params.id, action: "PASSWORD_RESET" });
  res.send(createResponse(result, "Password changed successfully"));
});